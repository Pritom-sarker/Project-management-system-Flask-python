import time
import datetime
import pandas as pd
from selenium import webdriver
from bs4 import BeautifulSoup

x = datetime.datetime.now()
n = x.strftime("__%b_%d_%Y")


def driver_conn():
    try:
        options = webdriver.ChromeOptions()
        options.add_argument("no-sandbox")
        # options.add_argument("--headless")
        options.add_argument("--disable-extensions")
        return webdriver.Chrome(executable_path="chromedriver.exe", options=options)
    except:
        options = webdriver.FirefoxOptions()
        options.add_argument("no-sandbox")
        options.add_argument("--headless")
        options.add_argument("--disable-extensions")
        return webdriver.Firefox(executable_path="geckodriver.exe", options=options)


def get_link_data():
    print('=================== Getting Link ===================')
    all_data = []
    links = []
    driver = driver_conn()
    driver.get('https://www.linkedin.com')
    input('Login your linkedin and Press Enter here: ')
    d = 0
    time.sleep(5)
    url = driver.current_url
    while True:
        d += 1
        time.sleep(3)
        driver.get(url + '&page=' + str(d))
        print('page >> ' + str(d))
        soup = BeautifulSoup(driver.page_source, 'html.parser')
        lis = soup.find_all('li', {'class': 'reusable-search__result-container'})
        if len(lis) == 0:
            break
        for li in lis:
            links.append(li.find('a', {'class': 'app-aware-link'})['href'])
            df = pd.DataFrame(links)
            df = df.rename_axis("Index")
            df.to_csv('links.csv')

    print('================ Getting Data ================')
    l = 0
    for link in links:
        l += 1
        name = ''
        role = ''
        location = ''
        company = ''
        skill = ''

        print('Link ' + str(l) + ' Out of ' + str(len(links)))
        driver.get(link)
        time.sleep(3)
        try:
            for i in range(1, 7):
                driver.execute_script("window.scrollTo(0, window.scrollY + 400)")
        except:
            pass
        time.sleep(5)
        soup = BeautifulSoup(driver.page_source, 'html.parser')
        try:
            name = soup.find('ul', {'class': 'pv-top-card--list'}).find('li', {'class': 'inline'}).text.replace(
                '\n            ', '')
        except:
            pass
        try:
            role = soup.find('h2', {'class': 'break-words'}).text.replace('\n            ', '')
        except:
            pass
        try:
            temps = soup.findAll('li', {'class': 'pv-skill-category-entity__top-skill'})
            for temp in temp:
                skill += temp.text
        except:
            pass
        try:
            location = soup.find('ul', {'class': 'pv-top-card--list-bullet'}).find('li', {
                'class': 'inline-block'}).text.replace('\n              ', '')
        except:
            pass
        try:
            company = soup.find('a', {'class': 'pv-top-card--experience-list-item'}).text.replace('\n', '')
        except:
            pass
        data = {
            'URL': link,
            'Name': name,
            'Current Role': role,
            'Skills': skill,
            'Location': location,
            'Company': company
        }
        # print(data)
        if name != '':
            all_data.append(data)
            df = pd.DataFrame(all_data)
            df = df.rename_axis("Index")
            df.to_csv('Final_Data_of_Linkedin' + n + '.csv')
    df = pd.DataFrame(all_data)
    df = df.rename_axis("Index")
    df.to_csv('Final_Data_of_Linkedin' + n + '.csv')
    print('================ Final Data Saved ================')


# ************************************* Run if you have links.csv **************************************************
def get_data():
    all_data = []
    driver = driver_conn()
    print('=================== Getting Data ===================')
    df = pd.read_csv('links.csv')
    links = df['0'].values

    driver.get('https://www.linkedin.com')
    input('Login your linkedin and Press Enter here: ')

    l = 0
    for link in links:
        l += 1
        print('Link ' + str(l) + ' Out of ' + str(len(links)))
        name = ''
        role = ''
        location = ''
        company = ''
        skill = ''
        driver.get(link)
        time.sleep(3)
        try:
            for i in range(1, 7):
                driver.execute_script("window.scrollTo(0, window.scrollY + 400)")
        except:
            pass
        time.sleep(5)
        soup = BeautifulSoup(driver.page_source, 'html.parser')
        # soup = BeautifulSoup(requests.get(link).content, 'html.parser')
        try:
            name = soup.find('ul', {'class': 'pv-top-card--list'}).find('li', {'class': 'inline'}).text.replace(
                '\n            ', '')
        except:
            pass
        try:
            role = soup.find('h2', {'class': 'break-words'}).text.replace('\n            ', '')
        except:
            pass
        try:
            temps = soup.findAll('li', {'class': 'pv-skill-category-entity__top-skill'})
            for temp in temps:
                skill += temp.text
        except:
            pass
        try:
            location = soup.find('ul', {'class': 'pv-top-card--list-bullet'}).find('li', {
                'class': 'inline-block'}).text.replace('\n              ', '')
        except:
            pass
        try:
            company = soup.find('a', {'class': 'pv-top-card--experience-list-item'}).text.replace('\n', '')
        except:
            pass
        data = {
            'URL': link,
            'Name': name,
            'Current Role': role,
            'Skills': skill,
            'Location': location,
            'Company': company
        }
        # print(data)
        if name != '':
            all_data.append(data)
            df = pd.DataFrame(all_data)
            df = df.rename_axis("Index")
            df.to_csv('Final_Data_of_Linkedin' + n + '.csv')
    df = pd.DataFrame(all_data)
    df = df.rename_axis("Index")
    df.to_csv('Final_Data_of_Linkedin' + n + '.csv')
    print('================ Final Data Saved ================')


if __name__ == '__main__':
    get_link_data()
    # get_data()

# ***************** If you have link.csv then run only get_data() other wise run get_link_data() *********************
