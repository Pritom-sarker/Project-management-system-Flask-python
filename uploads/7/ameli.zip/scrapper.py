from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.common import exceptions
from time import sleep
from datetime import datetime
import csv
from tqdm import tqdm
import requests
import pandas as pd

df = pd.read_excel('inputs.xlsx')

firefox_profile = webdriver.FirefoxProfile()
firefox_profile.set_preference('permissions.default.stylesheet', 2)
firefox_profile.set_preference('permissions.default.image', 2)
firefox_profile.set_preference(
    'dom.ipc.plugins.enabled.libflashplayer.so', 'false')
driver = webdriver.Firefox(firefox_profile=firefox_profile)


def scrap():
    sleep(1)
    soup = BeautifulSoup(driver.page_source, 'html.parser')
    try:
        # Name = driver.find_element_by_xpath(
        #     '//div[@class="nom_pictos"]').text.split()
        NameText = soup.find('div', {'class': 'nom_pictos'}).text
        Name = NameText.split()
        pass
    except:
        Name = ['', '', '']

    try:
        FirstName = Name[-1]
        pass
    except:
        FirstName = ""
        pass

    try:
        LastName = Name[-2]
        pass
    except:
        LastName = ""
        pass

    try:
        Gender = Name[-3]
        pass
    except:
        Gender = ""
        pass
    try:
        # profession = driver.find_element_by_xpath(
        #     '//h2[@class="item left specialite"]').text
        profession = soup.find('h2', {'class': 'item left specialite'}).text
        pass
    except:
        profession = ""
        pass

    try:
        # phone = driver.find_element_by_xpath(
        #     '//h2[@class="item left tel"]').text
        phone = soup.find('h2', {'class': 'item left tel'}).text
        pass
    except:
        phone = ""
        pass
    try:
        # address = driver.find_element_by_xpath(
        #     '//h2[@class="item left adresse"]').text
        address = soup.find('h2', {'class': 'item left adresse'}).text
        pass
    except:
        address = ""
        pass
    try:
        # Conventionne = driver.find_element_by_xpath(
        #     '//div[@class="item right convention"]').text
        Conventionne = soup.find(
            'div', {'class': 'item right convention'}).text
        pass
    except:
        Conventionne = ""
        pass
    try:
        # Carte_Vitale = driver.find_element_by_xpath(
        #     '//div[@class="item right mention_carte_vitale"]').text.replace('Carte Vitale :', '')
        Carte_Vitale = soup.find(
            'div', {'class': 'item right mention_carte_vitale'}).text.replace('Carte Vitale :', '')
        pass
    except:
        Carte_Vitale = ""
        pass
    try:
        # profession_status = driver.find_element_by_xpath(
        #     '//div[@class="item right type_activite"]').text
        profession_status = soup.find(
            'div', {'class': 'item right type_activite'}).text
        pass
    except:
        profession_status = ""
        pass

    return [FirstName, LastName, Gender, profession, phone, address, Conventionne, Carte_Vitale, profession_status, NameText]


head = ['FirstName', 'LastName', 'Gender', 'profession', 'phone',
        'address', 'Conventionne', 'Carte_Vitale', 'profession_status', 'Full Name', 'url']
output = [head]
start = int(input("Start Index: "))
for row in tqdm(df.values.tolist()[start:]):
    url = row[0]
    driver.get(url)
    try:
        output.append(scrap()+[url])
        while True:
            try:
                pd.DataFrame(output).to_excel('output.xlsx')
                break
            except:
                pass
        pass
    except:
        pass
    pass
